import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { fileURLToPath, URL } from "node:url";

export default defineConfig(({ mode }) => ({
  plugins: [react(), tailwindcss()],
  resolve: { alias: { "@": fileURLToPath(new URL("./src", import.meta.url)) } },
  server: {
    proxy: {
      "/api": {
        target:
          loadEnv(mode, process.cwd(), "").VITE_API_PROXY_TARGET ||
          "http://127.0.0.1:8000",
        changeOrigin: true,
      },
    },
  },
}));
